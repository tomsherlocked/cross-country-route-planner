import React from "react";

export default function WaypointMarker({ children }) {
  return <p className="map__marker">{children}</p>;
}
